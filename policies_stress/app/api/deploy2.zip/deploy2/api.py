from typing import List

from pydantic import BaseModel

from api.deploy2.func import NodeWithReason, find_optimal_node, get_prometheus_urls, insert_prometheus_url, Setting, \
    delete_prometheus_url
from core.db_postgresql import Postgresql, PostgresqlInfo
from core.routing import routing

router, _ = routing("deploy2", frontend=False, auth=True)

db = Postgresql(PostgresqlInfo(host="172.30.1.105", port=30081, database="postgres", user="hadmin", password="hadmin12!@"))

TEST_YAML = """
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: some-app
  name: some-app
  namespace: some
spec:
  replicas: 4
  selector:
    matchLabels:
      app: some-app
  template:
    metadata:
      labels:
        app: some-app
    spec:
      containers:
      - name: tespring
        image: lectinua/tespring:latest
        envFrom:
        - configMapRef:
            name: some-cfg
        ports:
        - containerPort: 8080
        resources:
          requests:
            cpu: 50m
            memory: 512Mi
            nvidia.com/gpu: 1
          limits:
            cpu: 500m
            memory: 1024Mi
            nvidia.com/gpu: 1
      tolerations:
      - key: "nvidia.com/gpu"
        value: "present"
        effect: "NoSchedule"
"""


class Prom(BaseModel):
    url: str


class Workload(BaseModel):
    yaml: str


@router.get("/info", description="더미 워크로드 yaml을 배포할 수 있는 최적의 노드를 찾아 반환")
async def get_optimal_node_info_from_dummy(workload=TEST_YAML) -> NodeWithReason:
    reason = await find_optimal_node(db, workload)
    return reason


@router.post("/info", description="워크로드 yaml을 문자열로 받아 배포할 수 있는 최적의 노드를 찾아 반환")
async def get_optimal_node_info(workload: Workload) -> NodeWithReason:
    reason = await find_optimal_node(db, workload.yaml)
    return reason


@router.get("/prom", description="등록된 수집용 프로메테우스 URL 목록")
async def get_collected_prometheus_urls() -> List[Setting]:
    urls = await get_prometheus_urls(db)
    return urls


@router.post("/prom", description="프로메테우스 URL 등록")
async def create_collected_prometheus_urls(prom: Prom):
    await insert_prometheus_url(db, prom.url)


@router.delete("/prom", description="등록된 프로메테우스 URL 삭제")
async def remove_collected_prometheus_urls(prom: Prom):
    await delete_prometheus_url(db, prom.url)
