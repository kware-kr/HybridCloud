# 임시
# from fastapi import FastAPI
#
# from api.deploy2.api import router as api_router
#
#
# def setup(app: FastAPI):
#     app.include_router(api_router)
