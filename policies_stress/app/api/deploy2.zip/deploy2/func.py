from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict, Tuple, Optional

import numpy as np
from dask.utils import parse_bytes
from hikaru import load_full_yaml, HikaruDocumentBase
from hikaru.meta import CatalogEntry
from hikaru.model.rel_1_23.v1.v1 import PodSpec, Container, ResourceRequirements
from pydantic import BaseModel

from api.metrics.func.db import Metric, get_collected_instances, get_metric_data_by_name, \
    get_avail_metrics_last_hours, set_metric_data_by_name
from api.metrics.func.pred import forecast
from core.db_postgresql import Postgresql
from util.date import dt2str

RESOURCE_NAMES: Dict[str, str] = {
    "cpu": "cpu_usage",
    "memory": "mem_usage",
    "disk": "dsk_usage"
}

REASON = "해당 워크로드는 {0} {1} 노드에 배치되는 것이 가장 최적으로 예상됩니다. resources에 따르면 {2}만큼 차지할 예정입니다."

QUERY_SETTING_SELECT = "SELECT value, description, date_created FROM setting WHERE type = '{0}'"

QUERY_SETTING_INSERT = "INSERT INTO setting (type, value, description, date_created) VALUES ('{0}', '{1}', '{2}', '{3}')"

QUERY_SETTING_DELETE = "DELETE FROM setting WHERE type = '{0}' AND value = '{1}'"


class NodeWithReason(BaseModel):
    node: Optional[str] = None
    reason: str


@dataclass
class Resource:
    name: str
    requests: int
    limits: int


@dataclass
class Score:
    value: Metric
    available: Metric
    workload: Dict[str, Resource]

    def get_total_score(self):
        return self.value.cpu_usage + self.value.mem_usage + self.value.dsk_usage


@dataclass
class Setting:
    value: str
    description: str
    date_created: datetime


# 워크로드의 spec 중 파드만 남기기
def entries_to_pod_specs(app: HikaruDocumentBase, entries: List[CatalogEntry]):
    pods: List[PodSpec] = []
    for entry in entries:
        obj = app.object_at_path(entry.path)
        if type(obj) == PodSpec:
            pods.append(obj)
    return pods


# CPU 코어 텍스트 변환
def parse_cpu_core(value: str) -> float:
    is_milli = "m" in value
    value = value.replace("m", "")

    if not is_milli:
        value = float(value) * 1000

    return float(value)


# hikaru로 얻은 resources를 Resource 클래스로 변환
def resource_requirements_to_custom_resource(resources: List[ResourceRequirements]) -> Dict[str, Resource]:
    resource_dict: dict[str, Resource] = {}
    for resource in resources:
        for resource_name in RESOURCE_NAMES.keys():
            if resource_name not in resource.requests:
                continue

            if resource_name == "cpu":
                requests = parse_cpu_core(resource.requests[resource_name])
                limits = parse_cpu_core(resource.limits[resource_name])
            else:
                requests = parse_bytes(resource.requests[resource_name])
                limits = parse_bytes(resource.limits[resource_name])

            new_resource = resource_dict.get(resource_name, Resource(name=resource_name, requests=0, limits=0))
            new_resource.requests += requests
            new_resource.limits += limits
            resource_dict[resource_name] = new_resource
    return resource_dict


# 워크로드를 Resource 클래스로 반환
def get_containers_resources(app: HikaruDocumentBase) -> Dict[str, Resource]:
    entries = app.find_by_name("spec")
    specs: List[PodSpec] = entries_to_pod_specs(app, entries)

    containers: List[Container] = []
    for spec in specs:
        containers += spec.containers

    resources: List[ResourceRequirements] = []
    for container in containers:
        if container.resources is not None:
            resources.append(container.resources)

    return resource_requirements_to_custom_resource(resources)


# 워크로드 텍스트로부터 requests, limits 반환
def get_resources_from_workload(workload: str) -> List[Dict[str, Resource]]:
    app_list: List[HikaruDocumentBase] = load_full_yaml(yaml=workload)
    resources = list(map(lambda app: get_containers_resources(app), app_list))
    return resources


# 노드별 남은 용량 예측 데이터 반환
async def get_avail_prediction_by_node(db: Postgresql, steps=4) -> List[Tuple[str, Metric]]:
    node_pred_set: List[Tuple] = []
    instances = await get_collected_instances(db)

    for instance in instances:
        metrics = await get_avail_metrics_last_hours(db, instance.node, instance.prometheus_url)
        predictions = []
        if len(metrics) > 0:
            predictions = forecast(metrics, steps)

        cpu_avails = []
        dsk_avails = []
        mem_avails = []

        if np.isnan(cpu_avails) or np.isnan(dsk_avails) or np.isnan(mem_avails):
            return []

        for pred in predictions:
            cpu_avails.append(pred.cpu_usage)
            dsk_avails.append(pred.dsk_usage)
            mem_avails.append(pred.mem_usage)

        prediction = Metric(cpu_usage=np.mean(cpu_avails), dsk_usage=np.mean(dsk_avails),
                            mem_usage=np.mean(mem_avails))
        node_pred_set.append((instance, prediction))

    return node_pred_set


# 리소스 점수 계산
def calc_resources_score(available: float, requests: int, limits: int) -> float:
    if available > requests:
        diff = available - limits
        if diff < 0:
            return 1
        return requests / available
    return 0


# 노드 점수 반환
def get_node_score(node_util: Metric, resources: Dict[str, Resource]) -> Metric:
    metric_score: Metric = Metric(cpu_usage=0, dsk_usage=0, mem_usage=0)
    excluded_resources = list(set(list(RESOURCE_NAMES.keys())).difference(list(resources.keys())))

    for resource_name in excluded_resources:
        metric_name = RESOURCE_NAMES[resource_name]
        set_metric_data_by_name(metric_score, metric_name, 1)

    for resource_name, resource in resources.items():
        metric_name = RESOURCE_NAMES[resource_name]

        current = get_metric_data_by_name(node_util, metric_name)
        requests = resources[resource_name].requests
        limits = resources[resource_name].limits

        score = 0
        if requests <= current:
            score = calc_resources_score(current, requests, limits)
        set_metric_data_by_name(metric_score, metric_name, score)

    return metric_score


# 최적의 배포 노드 찾기
async def find_optimal_node(db: Postgresql, workload: str) -> NodeWithReason:
    node_pred_set = await get_avail_prediction_by_node(db)
    workload_resources_by_app = get_resources_from_workload(workload)

    scores: Dict[str, Score] = {}
    for workload_resources in workload_resources_by_app:
        for node, util in node_pred_set:
            node_score: Metric = get_node_score(util, workload_resources)
            if node_score.cpu_usage == 0 or node_score.mem_usage == 0 or node_score.dsk_usage == 0:
                node_score = Metric(cpu_usage=0, mem_usage=0, dsk_usage=0)
            scores[node] = Score(value=node_score, available=util, workload=workload_resources)

    optimal_node = None
    if scores:
        optimal_node: str = max(scores, key=lambda k: scores[k].get_total_score())
        score = scores[optimal_node]
        reason = ""

        for workload in score.workload:
            available = get_metric_data_by_name(score.available, RESOURCE_NAMES[workload])
            requests = int(score.workload[workload].requests / available * 100)
            limits = int(score.workload[workload].limits / available * 100)
            if reason:
                reason += ", "
            reason += "{0}에서 {1}~{2}%".format(workload.capitalize(), requests, limits)

        eval_list = []
        if optimal_node == max(scores, key=lambda k: scores[k].value.cpu_usage):
            eval_list.append("Cpu에서 {0:.2f}점".format(score.value.cpu_usage))
        if optimal_node == max(scores, key=lambda k: scores[k].value.mem_usage):
            eval_list.append("Memory에서 {0:.2f}점".format(score.value.mem_usage))
        if optimal_node == max(scores, key=lambda k: scores[k].value.dsk_usage):
            eval_list.append("Disk에서 {0:.2f}점".format(score.value.dsk_usage))

        eval_list.append("총점 {0:.2f}".format(score.get_total_score()))
        eval_message = "{0}{1}".format(', '.join(eval_list), "으로")

        reason = REASON.format(eval_message, optimal_node, reason)
    else:
        reason = "오류"

    return NodeWithReason(node=optimal_node, reason=reason)


# 저장된 프로메테우스 URL 목록
async def get_prometheus_urls(db: Postgresql):
    rows = await db.fetch_all(QUERY_SETTING_SELECT.format("prom_url"))
    return list(map(lambda x: Setting(
        value=x[0],
        description=x[1],
        date_created=x[2]
    ), rows))


# 프로메테우스 URL 저장
async def insert_prometheus_url(db: Postgresql, url: str):
    date = dt2str(datetime.now())
    query = QUERY_SETTING_INSERT.format("prom_url", url, "", date)
    await db.execute(query)


# 프로메테우스 URL 삭제
async def delete_prometheus_url(db: Postgresql, url: str):
    await db.execute(QUERY_SETTING_DELETE.format("prom_url", url))
